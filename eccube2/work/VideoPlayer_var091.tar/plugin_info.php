<?php
/**
 * プラグイン の情報クラス.
 *
 * @package VideoPlayer
 * @author  Student.
 * @version $Id: $
 */
class plugin_info{
    static $PLUGIN_CODE       = "VideoPlayer";
    static $PLUGIN_NAME       = "埋め込み型動画プレイヤーブロック";
    static $CLASS_NAME        = "VideoPlayer";
    static $PLUGIN_VERSION     = "0.0.1";
    static $COMPLIANT_VERSION  = "2.12.0";
    static $AUTHOR            = " inc.";
    static $DESCRIPTION       = "埋め込み型動画プレイヤーを表示するブロックになります。";
    static $PLUGIN_SITE_URL    = "http://www.ec-cube.net/owners/index.php";
    static $AUTHOR_SITE_URL    = "http://www.ec-cube.net/";
    static $LICENSE          = "LGPL";
}
?>