<?php
/**
 * プラグイン の情報クラス.
 *
 * @package VideoPlayer
 * @author  Student.
 * @version $Id: $
 */
class plugin_info{
    static $PLUGIN_CODE       = "VideoPlayer";
    static $PLUGIN_NAME       = "埋め込み型動画プレイヤー";
    static $CLASS_NAME        = "VideoPlayer";
    static $PLUGIN_VERSION     = "0.8.4";
    static $COMPLIANT_VERSION  = "2.12.0";
    static $AUTHOR            = " Student.";
    static $DESCRIPTION       = "埋め込み型動画プレイヤーを表示する";
    static $PLUGIN_SITE_URL    = "http://xoops.ec-cube.net/";
    static $AUTHOR_SITE_URL    = "http://xoops.ec-cube.net/";
    static $LICENSE          = "LGPL";

}

?>